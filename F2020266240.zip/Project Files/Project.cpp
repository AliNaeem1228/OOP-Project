#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

class Drugs
{
protected:
	// Data Members
	char drugName[20];
	char drugID[7];

public:
	// Get Data Function
	void getDrug()
	{
		ifstream fin;
		fin.open("Drugs_Input.txt");

		fin.getline(drugName, 20);
		fin >> drugID;

		fin.close();
	}
	// Show Data Function
	void showDrug()
	{
		cout << "Name of the Drug: " << drugName << endl;
		cout << "Drug ID: " << drugID << endl;
	}
};

class Database : public Drugs // Child class Database inherited from Parent class Drugs
{
protected:
	// Data Members
	// Profit
	int salePrice;
	int purchasePrice;
	int profit;

	// Amount
	int totalDrugs;
	int soldDrugs;
	int leftDrugs;

	// Date
	int manufactureDay, manufactureMonth, manufactureYear;
	int expiryDay, expiryMonth, expiryYear;

public:
	~Database() // Constructor
	{
		salePrice = 0;
		purchasePrice = 0;
		profit = 0;

		totalDrugs = 0;
		soldDrugs = 0;
		leftDrugs = 0;

		manufactureDay = 0, manufactureMonth = 0, manufactureYear = 0;
		expiryDay = 0, expiryMonth = 0, expiryYear = 0;
	}
	// Get Data Functions
	void getProfit()
	{
		ifstream fin;
		fin.open("DatabaseProfit_Input.txt");

		fin >> salePrice;
		fin >> purchasePrice;

		fin.close();

		profit = salePrice - purchasePrice;
	}

	void getAmount()
	{
		ifstream fin;
		fin.open("DatabaseAmount_Input.txt");

		fin >> totalDrugs;
		fin >> soldDrugs;

		fin.close();

		leftDrugs = totalDrugs - soldDrugs;
	}

	void getDate()
	{
		ifstream fin;
		fin.open("DatabaseDate_Input.txt");

		fin >> manufactureDay >> manufactureMonth >> manufactureYear;
		fin >> expiryDay >> expiryMonth >> expiryYear;

		fin.close();
	}
	
	// Show Data Functions
	void showProfit()
	{
		cout << "\t\tProfit\n";
		cout << "Sale Price: " << salePrice << endl;
		cout << "Purchase Price: " << purchasePrice << endl;
		cout << "Profit: " << profit << endl;
	}

	void showAmount()
	{
		cout << "\t\tAmound Left\n";
		cout << "Total Number of Drugs: " << totalDrugs << endl;
		cout << "Amount of Drugs Sold: " << soldDrugs << endl;
		cout << "Amount of Drugs Remaining: " << leftDrugs << endl;
	}

	void showDate()
	{
		cout << "\t\tValidity Period\n";

		// Applying Checks to see if dates entered are correct or not

		// For Manufacturing Date
		// If Day and month exceeds their specified numbers then it will give error
		if (manufactureDay > 31 || manufactureMonth > 12)
		{
			cout << "Wrong Date, Please Change the Date" << endl;
		}
		// February Month only have 28 days so program will give error if date entered is above 28
		else if (manufactureDay > 28 && manufactureMonth == 2)
		{
			cout << "Wrong Date, Please Change the Date" << endl;
		}
		// Months which does not have days more than 30 will give error if date is entered above 30 (e.g. April does not have 31 days)
		else if(manufactureDay > 30 && manufactureMonth == 4 || manufactureMonth == 6 || manufactureMonth == 9 || manufactureMonth == 11)
		{
			cout << "Wrong Date, Please Change the Date" << endl;
		}

		// For Expiry Date
		// If Day and month exceeds their specified numbers then it will give error
		if (expiryDay > 31 || expiryMonth > 12)
		{
			cout << "Wrong Date, Please Change the Date" << endl;
		}
		// February Month only have 28 days so program will give error if date entered is above 28
		else if (expiryDay > 28 && expiryMonth == 2)
		{
			cout << "Wrong Date, Please Change the Date" << endl;
		}
		// Months which does not have days more than 30 will give error if date is entered above 30 (e.g. April does not have 31 days)
		else if (expiryDay > 30 && expiryMonth == 4 || expiryMonth == 6 || expiryMonth == 9 || expiryMonth == 11)
		{
			cout << "Wrong Date, Please Change the Date" << endl;
		}

		else
		{
			//setfill and setw used with the help iomanip header file, Since Date is in DD/MM/YYYY format it will put 0 behind single digit entry (e.g. 2 will become 02)
			cout << "Manufacturing Date: " << setw(2) << setfill('0') << manufactureDay << "-" << setw(2) << setfill('0')<< manufactureMonth << "-" << setw(4) << setfill('0') << manufactureYear << endl;
			cout << "Expiry Date: " << setw(2) << setfill('0') << expiryDay << "-" << setw(2) << setfill('0') << expiryMonth << "-" << setw(4) << setfill('0') << expiryYear << endl;
			cout << "Best Before: " << setw(2) << setfill('0') << expiryDay << "-" << setw(2) << setfill('0') << expiryMonth << "-" << setw(4) << setfill('0') << expiryYear << endl;
		}
	}
};

int main()
{
	cout << "\t\t*****Welcome to Dispensary Management System*****" << endl << endl;
	bool run = true;
	int choice;

	Database d1;
	d1.getDrug();
	d1.showDrug();
	d1.~Database();

	cout << endl;
	cout << "What Would You Like to Check?" << endl;
	cout << "Press 1 for Profit" << endl;
	cout << "Press 2 for Amount Left" << endl;
	cout << "Press 3 for Expiry Date Checking" << endl;
	cout << "Press 4 to Exit the Program" << endl;
	cout << endl;

	while (run)
	{
		cout << "Please Enter Choice: ";
		cin >> choice;

		switch (choice)
		{
		case 1:
			cout << endl;
			d1.getProfit();
			d1.showProfit();
			cout << endl;
			break;
		case 2:
			cout << endl;
			d1.getAmount();
			d1.showAmount();
			cout << endl;
			break;
		case 3:
			cout << endl;
			d1.getDate();
			d1.showDate();
			cout << endl;
			break;
		case 4:
			cout << "\nExiting Program \nGood Bye :D" << endl;
			run = false;
			break;
		default:
			cout << "\nError!! Please Input from the Given Options" << endl << endl;
			break;
		}
	}
	return 0;
}